/* Here you can configure Daniel */

var SiteStartDate = "2020/11/7 08:05",
  gmap_address = "central park new york", // Enter here address of marker on google map
  YoutubeBgCode = "tf_EZU_t76c"; // The Date Of Site Opening

var gmap_styles = [
  {
    featureType: "landscape",
    elementType: "labels",
    stylers: [{ visibility: "off" }],
  },
  {
    featureType: "transit",
    elementType: "labels",
    stylers: [{ visibility: "off" }],
  },
  {
    featureType: "poi",
    elementType: "labels",
    stylers: [{ visibility: "off" }],
  },
  {
    featureType: "water",
    elementType: "labels",
    stylers: [{ visibility: "off" }],
  },
  {
    featureType: "road",
    elementType: "labels.icon",
    stylers: [{ visibility: "off" }],
  },
  {
    stylers: [
      { hue: "#00aaff" },
      { saturation: -100 },
      { gamma: 2.15 },
      { lightness: 12 },
    ],
  },
  {
    featureType: "road",
    elementType: "labels.text.fill",
    stylers: [{ visibility: "on" }, { lightness: 24 }],
  },
  {
    featureType: "road",
    elementType: "geometry",
    stylers: [{ lightness: 57 }],
  },
];
